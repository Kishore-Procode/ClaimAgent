# VisionClaim Investigator — AI Forensic Claims Investigator

An advanced multi-agent forensic verification engine designed to answer the core question: **"Does the visual evidence support the damage claim?"**

This repository implements a 7-core-agent pipeline with 3 optional bonus agents using a unified cloud-inference VLM architecture via the OpenRouter API.

---

## 🏗️ System Architecture

Unlike standard vision classifiers that simply output "supported" or "contradicted" based on a single image scan, VisionClaim Investigator runs an interactive forensic verification process across **7 Core Agents** and **3 Bonus Agents**:

```
Claims CSV Row
     │
     ▼
[1] Claim Extractor ──────────► Extracts parts/damage types from conversation
     │
     ▼
[2] Evidence Requirement ─────► Maps parts/damage types to required visual evidence
     │
     ▼
[3] Image Analyzer ───────────► Performs vision analysis per image + merged check
     ├────────────────────────► [8] Authenticity (Bonus): Checks EXIF metadata
     └────────────────────────► [9] Duplicate (Bonus): Perceptual image hashing
     │
     ▼
[4] Coverage Analyzer ────────► Cross-references visible parts vs required parts
     │
     ▼
[5] History Risk ─────────────► Evaluates frequency/patterns in user claim history
     │
     ▼
[6] Contradiction ────────────► Identifies severity/part mismatches + prompt injections
     │
     ▼
[7] Verdict ──────────────────► Aggregates evidence and produces the 14-column schema
     │
     ▼
[10] Self-Critique (Bonus) ───► Challenges the primary verdict and suggests revisions
     │
     ▼
Final output.csv row
```

---

## 🛠️ Custom Moves & Enhancements

Here are the custom engineering changes and optimizations built into this AI engine:

1. **Cloud-Based API Migration (Zero Local GPU)**:
   - Replaced heavy local model downloads (`torch`/`transformers` stack requiring >16GB VRAM) with a clean OpenAI-compatible **OpenRouter API client**.
   - Integrates `qwen/qwen2.5-vl-72b-instruct` (primary) and `qwen/qwen3-vl-8b-instruct` (fallback) to run text reasoning and vision analysis in a single load.
   
2. **Resilience & Connection Recovery**:
   - Built exponential backoff retry handlers to manage OpenRouter rate limits.
   - Designed a non-fatal exception catcher per claim. If the network drops or an API call fails, the pipeline isolates the error and generates an **emergency fallback verdict** (so the CSV output remains structural and complete).

3. **Robust Path Normalization**:
   - Added automatic normalization to `evaluation/metrics.py` and `evaluation/compare_predictions.py` that strips absolute path prefixes (`data/` / `D:\`) and matches slashes (`\` vs `/`). This ensures evaluation compares predicted paths to ground truth correctly.

4. **Unicode Console Protection**:
   - Replaced all Unicode box-drawing (`─`, `═`) and indicator characters (`✗`, `✓`) with standard ASCII symbols (`-`, `=`, `[X]`, `[OK]`) in CLI outputs to prevent encoding crashes on Windows PowerShell.

5. **Self-Critique Engine**:
   - Implemented an optional agent that reviews the generated verdict, identifies potential assumptions, challenges the reasoning, and rewrites the final justification to be highly objective and image-grounded.

6. **Authenticity & Duplicate Checks**:
   - **EXIF Analyzer**: Parses embedded metadata to spot missing timestamps or suspicious camera configurations.
   - **Perceptual Hashing**: Uses `imagehash` to generate visual fingerprints of all processed images, flagging users who attempt to reuse identical images across multiple claims.

---

## 📋 Schema Details

### Input CSV Columns (4)
- `user_id`: Unique identifier for the claimant.
- `image_paths`: Semicolon-separated paths to submitted images.
- `user_claim`: Plaintext or formatted conversation history.
- `claim_object`: The subject of the claim (`car` | `laptop` | `package`).

### Output CSV Columns (14)
The engine produces an `output.csv` matching the required schema:
1. `user_id` (pass-through)
2. `image_paths` (pass-through)
3. `user_claim` (pass-through)
4. `claim_object` (pass-through)
5. `evidence_standard_met` (`true` | `false`)
6. `evidence_standard_met_reason` (explanation of parts covered/missing)
7. `risk_flags` (semicolon-joined vocabulary, or `none`)
8. `issue_type` (`dent` | `crack` | `scratch` | `broken_part` | `stain` | `torn_packaging` | `crushed_packaging` | `water_damage` | `unknown` | `none`)
9. `object_part` (the exact part claimed, e.g. `rear_bumper`, `screen`)
10. `claim_status` (`supported` | `contradicted` | `not_enough_information`)
11. `claim_status_justification` (forensic justification text)
12. `supporting_image_ids` (semicolon-joined list of image IDs, e.g. `img_1;img_2`)
13. `valid_image` (`true` | `false`)
14. `severity` (`low` | `medium` | `high` | `critical` | `unknown` | `none`)

---

## 🚀 Setup & Execution

### 1. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 2. Configure API Key
Set your OpenRouter API key as an environment variable (the script also contains a default fallback key):
```powershell
$env:OPENROUTER_API_KEY = "your-openrouter-key"
```

### 3. Run Pipeline on Sample Data
```powershell
python main.py --input data/sample_claims.csv --output outputs/sample_output.csv --data-dir data/
```

### 4. Evaluate Prediction Accuracy
Compare the predictions against ground truth sample data:
```powershell
python evaluation/evaluator.py -p outputs/sample_output.csv -g data/sample_claims.csv
```

Identify specific mismatches side-by-side:
```powershell
python evaluation/compare_predictions.py -p outputs/sample_output.csv -g data/sample_claims.csv
```

### 5. Process Full Test Dataset
```powershell
python main.py --input data/claims.csv --output outputs/output.csv --data-dir data/
```

### ⚙️ Command-Line Flags
- `--dry-run`: Loads datasets and checks configurations without sending API requests.
- `--limit N`: Process only the first N rows (highly recommended for fast testing).
- `--no-authenticity`: Disables EXIF checking.
- `--no-duplicate`: Disables perceptual image hashing.
- `--no-critique`: Disables the self-critique revision step (speeds up run times).
